
local function suspend()
	print("suspending ...")
	exec("sh", "-c", "echo '7 blink' > /proc/acpi/ibm/led")
	exec("sh", "-c", "sync")
	exec("sh", "-c", "echo mem > /sys/power/state")
end

script[10] = function(hid, event, data)
	print(hid, event, data);
end

script[20] = function(hid, event, data)
end

script[50] = function(hid, event, data)
	-- if (hid == "IBM0068:00") then suspend() end
end

